package org.example.java8;

/**
 * Created by Aman on 08/09/16.
 */
public interface InterfaceWithArgs {
    public void calculate(int value1, int value2);
}
