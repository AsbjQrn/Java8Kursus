package org.example.java8;

/**
 * Created by Aman on 08/09/16.
 */
public interface SimpleInterface {
    public void doSomething();
}
